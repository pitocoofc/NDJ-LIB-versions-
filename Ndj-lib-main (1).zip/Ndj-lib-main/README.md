# 🚀 Ndj-lib (v1.0.9)
A biblioteca definitiva para criar bots de Discord complexos diretamente do Termux.
Desenvolvida com foco em simplicidade e performance mobile, a Ndj-lib permite que você transforme seu celular em uma central de desenvolvimento de bots, sem a necessidade de um PC.


# 👨‍💻 Sobre o Projeto
A Ndj-lib foi projetada especificamente para:
Desenvolvedores Mobile: Otimizada para rodar de forma leve no Termux.
Modularidade Total: Instale funções (Economia, IA, Moderação) com um único comando sem mexer no código principal.
Facilidade de Uso: Esqueça configurações complexas de APIs; foque apenas na lógica do seu bot.


# 🛡️ Autoria e Direitos
Este é um projeto Open Source protegido pela Licença MIT.
Criador: Ghost (pitocoofc).
Repositório Oficial: github.com/pitocoofc/Ndj-lib.
Nota: Você é livre para clonar e modificar, mas a manutenção dos créditos originais no console e nos arquivos de licença é obrigatória por lei e por respeito ao desenvolvimento mobile.


# ⚠️ Limites e Avisos
Para garantir a melhor experiência no celular, a lib possui alguns limites de projeto:
Dependências: Requer Node.js instalado no Termux.
Segurança: Em repositórios públicos, não utilize chaves de API externas. Utilize apenas as funções de respostas pré-definidas incluídas nos módulos oficiais para evitar vazamentos.
Compatibilidade: Utilize sempre a versão mais recente para garantir que os módulos oficiais funcionem corretamente com as mudanças da API do Discord.
🛠️ Instalação Rápida
No seu terminal Termux, utilize o nosso assistente exclusivo:

# Clone o repositório
git clone https://github.com/pitocoofc/Ndj-lib.git

# Entre na pasta e instale os módulos que desejar
./dnt install pitocoofc/dnt-ia

./dnt install pitocoofc/dnt-economy


# 🌟 Versão Atual: 1.0.9
Sistema de créditos automático no console.
Suporte a Slash Commands (Comandos de Barra).
Novo módulo de IA por respostas pré-definidas (Seguro para GitHub).



Esse projeto está em beta aberta e não possui uma linguagem de programação avançada...apenas compatibilidade e resumo de node.js para discord.js com uma camada de simplificação 


# Para desenvolvedores
Deseja criar seu modulo? copie o codigo e o repositório dos modulos oficiais e altere para seu sistema ou espere o servidor do discord


# ⚠️ AVISO
A NDJ-LIB é um projeto de código aberto e não possui um servidor de comunidade oficial.
​Suporte: Solicite ajuda apenas respondendo a mensagens oficiais em posts no Reddit vinculados à conta do criador (Ghost/pitocoofc).
​Segurança: Não nos responsabilizamos por módulos baixados de terceiros. A segurança da lib depende do uso de fontes oficiais e manutenção ativa.
​Instalação Oficial: Utilize sempre o comando ./dnt install pitocoofc/NOME_DO_MODULO para garantir que está baixando um recurso avaliado pela administração.


# 🤝 Contribuição e Suporte
Deseja auxiliar no desenvolvimento da Ndj-lib ou solicitar suporte técnico?
Onde me encontrar: Estou presente no servidor oficial de Node.js no Discord utilizando o pseudônimo Kelvyn (kelvyn43527).
Endereço do Servidor: discord.gg/nodejs
Aviso: Este é o único meio de comunicação direta além das threads oficiais no Reddit.
