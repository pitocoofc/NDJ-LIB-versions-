# Ndj-Lib
none
nenhuma
ninguno
keiner

# Modules 
Add new economy system
Add new embed system
Improvement in the economic system 


# community
N/A


# Support language
Português-PT
Português-BR

# Goals 

Automatic log translation system
Discord community
Version 1.1.0 enhanced with native hosting via render.
25 more modules and exceptional improvements. 
develop a breathing module (lol)



# updates 
0.1: I don't remember (lol)
0.2: It never existed.(I jumped to 0.5)
0.5: Pure Node.js with smart correction. 
0.8 Non-functional library
0.9 Official start
1.0.0 Functional version 
1.0.1 It also doesn't exist.(lol)
1.0.9 current
