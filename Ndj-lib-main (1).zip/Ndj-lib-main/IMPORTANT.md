EN: This is a raw version of ndj-lib with frequent updates and direct support...the library in this repository may increase by some MBs.
Do you want a lightweight experience? I'll be filtering the content repository in the future and also adding a command for users to clean up non-essential files themselves. 

ES: Esta es una versión básica de ndj-lib con actualizaciones frecuentes y soporte directo... el tamaño de la biblioteca en este repositorio puede aumentar en algunos MB.
¿Quieres una experiencia ligera? Filtraré el contenido.

PT: Esta é uma versão básica da ndj-lib com atualizações frequentes e suporte direto... a biblioteca neste repositório pode aumentar em alguns MBs.
Você quer uma experiência mais leve? Vou filtrar o conteúdo.

GE: Dies ist eine Rohversion von ndj-lib mit regelmäßigen Updates und direktem Support. Die Bibliothek in diesem Repository kann um einige Megabyte anwachsen.
Wünschen Sie eine schlanke Version? Ich werde die Inhalte entsprechend filtern.

RU: Это базовая версия ndj-lib с частыми обновлениями и прямой поддержкой... размер библиотеки в этом репозитории может увеличиться на несколько мегабайт.
Хотите более лёгкий интерфейс? Я буду фильтровать контент.

SC: Detta är en råversion av ndj-lib med frekventa uppdateringar och direkt support... biblioteket i detta arkiv kan öka med några MB.
Vill du ha en lättviktig upplevelse? Jag kommer att filtrera innehållet.

FR: Il s'agit d'une version brute de ndj-lib avec des mises à jour fréquentes et un support direct… la taille de la bibliothèque dans ce dépôt peut augmenter de quelques mégaoctets.
Vous souhaitez une expérience plus légère ? Je filtrerai le contenu.

IT: Questa è una versione grezza di ndj-lib con aggiornamenti frequenti e supporto diretto... la libreria in questo repository potrebbe aumentare di qualche MB.
Desideri un'esperienza più leggera? Filtrerò i contenuti.

CH: 這是 ndj-lib 的原始版本，會頻繁更新並提供直接支援…此倉庫中的庫檔案大小可能會增加幾兆位元組。
想要輕量級體驗？我會對內容進行過濾。

JP: これは、頻繁なアップデートと直接サポート付きのndj-libのRAWバージョンです。このリポジトリのライブラリは数MB増加する可能性があります。
軽量版をご希望ですか？コンテンツをフィルタリングします。

ESLO: To je surova različica knjižnice ndj-lib s pogostimi posodobitvami in neposredno podporo ... knjižnica v tem repozitoriju se lahko poveča za nekaj MB.
Ali želite lahkotno izkušnjo? Vsebino bom filtriral.

ESLOVA: Toto je surová verzia knižnice ndj-lib s častými aktualizáciami a priamou podporou... knižnica v tomto repozitári sa môže zväčšiť o niekoľko MB.
Chcete ľahký zážitok? Budem filtrovať obsah.

ALB: Ky është një version i papërpunuar i ndj-lib me përditësime të shpeshta dhe mbështetje të drejtpërdrejtë... biblioteka në këtë depo mund të rritet me disa MB.
Dëshironi një përvojë të lehtë? Do ta filtroj përmbajtjen.

ARA: هذه نسخة أولية من مكتبة ndj-lib مع تحديثات متكررة ودعم مباشر... قد يزيد حجم المكتبة في هذا المستودع بضعة ميغابايتات.

هل ترغب بتجربة استخدام خفيفة؟ سأقوم بتصفية المحتوى.

BIELO: Гэта неапрацаваная версія ndj-lib з частымі абнаўленнямі і непасрэднай падтрымкай... бібліятэка ў гэтым рэпазітарыі можа павялічыцца на некалькі МБ.
Хочаце лёгкі інтэрфейс? Я буду фільтраваць кантэнт.


Agora vocês me perguntam....Um desencolvedor solo deu preferência para colocar mais de 16 linguagens em um unico aviso ao inves do projeto? E eu respondo...Sim

