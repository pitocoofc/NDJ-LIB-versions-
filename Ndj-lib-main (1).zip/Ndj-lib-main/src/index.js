module.exports = {
    EasyBot: require('./Client'),
    Context: require('./Context')
};
